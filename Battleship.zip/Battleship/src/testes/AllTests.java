package testes;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
@SelectClasses({ FleetTest.class, PositionTest.class, GameTest.class, BargeTest.class, CaravelTest.class, CompassTest.class, CarrackTest.class, FrigateTest.class,GalleonTest.class,ShipTest.class,GameTest.class })

public class AllTests {

}
