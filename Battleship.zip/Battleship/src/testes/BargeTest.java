package testes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import battleship.Barge;
import battleship.Caravel;
import battleship.Compass;
import battleship.IShip;
import battleship.Position;

class BargeTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Barge barge = null;
		assertNull(barge);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testGetSize() {
		IShip ship = new Caravel(Compass.EAST, new Position(2, 2));
		ship.getSize();
	}

	@Test
	void testBarge() {
		IShip ship = new Caravel(Compass.EAST, new Position(2, 2));
		assertNotNull(ship);
	}

	@Test
	void testGetName() {
		assertEquals(Barge.getName(),"Barca");
	}

}
