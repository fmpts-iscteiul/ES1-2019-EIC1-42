package testes;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import battleship.Caravel;
import battleship.Compass;
import battleship.Fleet;
import battleship.IShip;
import battleship.Position;

class CaravelTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Caravel caravel = null;
		assertNull(caravel);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testGetSize() {
		IShip ship;
		ship = new Caravel(Compass.WEST, new Position(2,2));
		ship.getSize();
	}

	@Test
	void testCaravel() {
		IShip ship;
		ship = new Caravel(Compass.WEST, new Position(2,2));
		ship = new Caravel(Compass.EAST, new Position(2,2));
		ship = new Caravel(Compass.NORTH, new Position(2,2));
		ship = new Caravel(Compass.SOUTH, new Position(2,2));
		ship = new Caravel(Compass.INVALID, new Position(2,2));
		
	}

	@Test
	void testGetName() {
		assertEquals(Caravel.getName(), "Caravela");
		
	}

}
