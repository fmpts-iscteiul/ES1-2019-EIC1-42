package testes;

import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import battleship.Carrack;
import battleship.Compass;
import battleship.IShip;
import battleship.Position;

class CarrackTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Carrack carrack = null;
		assertNull(carrack);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testGetSize() {
		IShip ship;
		ship = new Carrack(Compass.WEST, new Position(2,2));
		ship.getSize();
	}

	@Test
	void testCarrack() {
		IShip ship;
		ship = new Carrack(Compass.WEST, new Position(2,2));
		ship = new Carrack(Compass.EAST, new Position(2,2));
		ship = new Carrack(Compass.NORTH, new Position(2,2));
		ship = new Carrack(Compass.SOUTH, new Position(2,2));
		ship = new Carrack(Compass.INVALID, new Position(2,2));
	}

}
