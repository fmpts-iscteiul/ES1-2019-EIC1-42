package testes;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import battleship.Compass;

class CompassTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Compass compass = null;
		assertNull(compass);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testCompass() {
		Compass compass;
		compass = Compass.NORTH;
		compass = Compass.SOUTH;
		compass = Compass.EAST;
		compass = Compass.WEST;
	}

	@Test
	void testToString() {
		Compass compass;
		compass = Compass.NORTH;
		compass.toString();
	}

}
