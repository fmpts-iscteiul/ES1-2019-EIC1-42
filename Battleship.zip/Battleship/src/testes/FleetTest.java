package testes;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import battleship.Barge;
import battleship.Caravel;
import battleship.Compass;
import battleship.Fleet;
import battleship.IShip;
import battleship.Position;

class FleetTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Fleet fleet = null;
		assertNull(fleet);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testFleet() {
		Fleet fleet = new Fleet();
		assertNotNull(fleet.getShips());
	}

	@Test
	void testAddShip() {
		Fleet fleet = new Fleet();
		IShip ship;

		for (int i = 0; i < Fleet.SQUAREGRIDSIZE + 3; i++) {
			ship = new Caravel(Compass.EAST, new Position(2, 2));
			fleet.addShip(ship);
			ship = new Barge(Compass.EAST, new Position(2, -4));
			fleet.addShip(ship);
			ship = new Barge(Compass.NORTH, new Position(22, 1));
			fleet.addShip(ship);
			ship = new Barge(Compass.NORTH, new Position(2, i));
			fleet.addShip(ship);
			ship = new Barge(Compass.NORTH, new Position(3, i - 1));
			fleet.addShip(ship);
			ship = new Barge(Compass.NORTH, new Position(4, i - 1));
			fleet.addShip(ship);
			ship = new Caravel(Compass.WEST, new Position(0, -1));
			fleet.addShip(ship);
			ship = new Caravel(Compass.WEST, new Position(0, Fleet.SQUAREGRIDSIZE));
			fleet.addShip(ship);
			ship = new Barge(Compass.NORTH, new Position(-1, 0));
			fleet.addShip(ship);
			ship = new Caravel(Compass.WEST, new Position(0, 0));
			fleet.addShip(ship);
			ship = new Caravel(Compass.EAST, new Position(4,4));
			fleet.addShip(ship);
		}
	}

	@Test
	void testListShipsLike() {
		IShip ship;
		Fleet fleet;
		ship = new Barge(Compass.NORTH, new Position(2, 3));
		fleet = new Fleet();
		fleet.addShip(ship);
		fleet.listShipsLike(Barge.getName());
		ship = new Caravel(Compass.NORTH, new Position(2, 3));
		fleet = new Fleet();
		fleet.addShip(ship);
		fleet.listShipsLike(Barge.getName());

	}

	@Test
	void testListFloatingShips() {
		Fleet fleet = new Fleet();
		IShip ship;
		ship = new Caravel(Compass.NORTH, new Position(2, 3));
		fleet.addShip(ship);
		fleet.listFloatingShips();
		ship = new Barge(Compass.NORTH, new Position(0, 0));
		fleet.addShip(ship);
		ship.shoot(new Position(0, 0));
		fleet.listFloatingShips();
	}

	@Test
	void testListAllShips() {
		Fleet fleet = new Fleet();
		IShip ship;
		ship = new Caravel(Compass.NORTH, new Position(2, 3));
		fleet.addShip(ship);
		fleet.listAllShips();
	}

	@Test
	void testShipAt() {
		Fleet fleet = new Fleet();
		IShip ship;
		ship = new Caravel(Compass.NORTH, new Position(2, 3));
		fleet.addShip(ship);
		fleet.shipAt(new Position(0, 0));
		fleet.shipAt(new Position(2, 3));

	}
}
