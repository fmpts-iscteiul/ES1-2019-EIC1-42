package testes;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import battleship.Compass;
import battleship.Galleon;
import battleship.Position;

class GalleonTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Galleon galleon = null;
		assertNull(galleon);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testGetSize() {
		Galleon galleon = new Galleon(Compass.SOUTH,new Position(2,3));
		galleon.getSize();
	}

	@Test
	void testGalleon() {
		Galleon galleon;
		galleon = new Galleon(Compass.SOUTH,new Position(2,3));
		galleon = new Galleon(Compass.NORTH,new Position(2,3));
		galleon = new Galleon(Compass.WEST,new Position(2,3));
		galleon = new Galleon(Compass.EAST,new Position(2,3));
		galleon = new Galleon(Compass.INVALID,new Position(2,3));
	}

}
