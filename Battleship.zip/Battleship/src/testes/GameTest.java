package testes;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import battleship.Barge;
import battleship.Carrack;
import battleship.Compass;
import battleship.Fleet;
import battleship.Game;
import battleship.IPosition;
import battleship.IShip;
import battleship.Position;

class GameTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Game game = null;
		assertNull(game);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testGame() {
		new Game(new Fleet());
	}

	@Test
	void testFire() {
		Fleet fleet = new Fleet();
		IShip ship1 = new Barge(Compass.EAST,new Position(2,3));
		IShip ship2 = new Carrack(Compass.NORTH,new Position(0,0));
		fleet.addShip(ship1);
		fleet.addShip(ship2);
		Game game = new Game(fleet);
		game.fire(new Position(4,4));
		game.fire(new Position(4,4));
		game.fire(new Position(Fleet.SQUAREGRIDSIZE + 1,4));
		game.fire(new Position(0,Fleet.SQUAREGRIDSIZE + 1));
		game.fire(new Position(-1,-1));
		game.fire(new Position(2,3));
		game.fire(new Position(0,0));
		game.fire(new Position(4,-2));
		
		
	}

	@Test
	void testGetShots() {
		new Game(new Fleet()).getShots();
	}

	@Test
	void testGetRepeatedShots() {
		new Game(new Fleet()).getRepeatedShots();
	}

	@Test
	void testGetInvalidShots() {
		new Game(new Fleet()).getInvalidShots();
	}

	@Test
	void testGetHits() {
		new Game(new Fleet()).getHits();
	}

	@Test
	void testGetSunkShips() {
		new Game(new Fleet()).getSunkShips();
	}

	@Test
	void testGetRemainingShips() {
		new Game(new Fleet()).getRemainingShips();
	}

	@Test
	void testGetFleet() {
		new Game(new Fleet()).getFleet();
	}

	@Test
	void testSetFleet() {
		new Game(new Fleet()).setFleet(new Fleet());
	}

	@Test
	void testGetCountInvalidShots() {
		new Game(new Fleet()).getCountInvalidShots();
	}

	@Test
	void testSetCountInvalidShots() {
		new Game(new Fleet()).setCountInvalidShots(2);
	}

	@Test
	void testGetCountRepeatedShots() {
		new Game(new Fleet()).getCountRepeatedShots();
	}

	@Test
	void testSetCountRepeatedShots() {
		new Game(new Fleet()).setCountRepeatedShots(2);
	}

	@Test
	void testGetCountHits() {
		new Game(new Fleet()).getCountHits();
	}

	@Test
	void testSetCountHits() {
		new Game(new Fleet()).setCountHits(2);
	}

	@Test
	void testGetCountSinks() {
		new Game(new Fleet()).getCountSinks();
	}

	@Test
	void testSetCountSinks() {
		new Game(new Fleet()).setCountSinks(2);
	}

	@Test
	void testSetShots() {
		new Game(new Fleet()).setShots(new ArrayList<IPosition>());
	}

}
