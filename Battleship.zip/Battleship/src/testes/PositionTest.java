package testes;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import battleship.Position;

class PositionTest {

	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Position pos = null;
		assertNull(pos);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testPosition() {
		Position position = new Position(2,3);
		assertTrue(position.getRow() == 2);
		assertTrue(position.getColumn() == 3);
		assertFalse(position.isHit());
		assertFalse(position.isOccupied());
	}

	@Test
	void testGetRow() {
		assertEquals(new Position(2,3).getRow(),2);
	}

	@Test
	void testGetColumn() {
		assertEquals(new Position(2,3).getColumn(),3);
	}

	@Test
	void testEqualsIPosition() {
		assertTrue(new Position(2,3).equals(new Position(2,3)));
		assertFalse(new Position(2,3).equals(new Position(2,2)));
		assertFalse(new Position(2,3).equals(new Position(1,3)));
	}

	@Test
	void testIsAdjacentTo() {
		assertTrue(new Position(2,3).isAdjacentTo(new Position(2,2)));
		assertFalse(new Position(2,3).isAdjacentTo(new Position(0,3)));
		assertFalse(new Position(2,3).isAdjacentTo(new Position(4,5)));
		assertFalse(new Position(2,3).isAdjacentTo(new Position(2,5)));
	}

	@Test
	void testOccupy() {
		new Position(2,3).occupy();
		
	}

	@Test
	void testShoot() {
		new Position(2,3).shoot();
	}

	@Test
	void testIsOccupied() {
		assertFalse(new Position(2,3).isOccupied());
	}

	@Test
	void testIsHit() {
		assertFalse(new Position(2,3).isHit());
	}

	@Test
	void testToString() {
		new Position(2,3).toString();
	}

}
