package testes;

import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import battleship.Barge;
import battleship.Caravel;
import battleship.Carrack;
import battleship.Compass;
import battleship.IShip;
import battleship.Position;

class ShipTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		IShip ship = null;
		assertNull(ship);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testShip() {
		IShip ship;
		ship = new Barge(Compass.NORTH,new Position(2,3));
	}

	@Test
	void testGetCategory() {
		IShip ship;
		ship = new Barge(Compass.NORTH,new Position(2,3));
		ship.getCategory();
	}

	@Test
	void testGetSize() {
		IShip ship;
		ship = new Barge(Compass.NORTH,new Position(2,3));
		ship.getSize();
	}

	@Test
	void testGetPosition() {
		IShip ship;
		ship = new Barge(Compass.NORTH,new Position(2,3));
		ship.getPosition();
		
	}

	@Test
	void testGetBearing() {
		IShip ship;
		ship = new Barge(Compass.NORTH,new Position(2,3));
		ship.getBearing();
	}

	@Test
	void testStillFloating() {
		IShip ship;
		ship = new Barge(Compass.NORTH,new Position(2,3));
		ship.stillFloating();
		ship.shoot(new Position(2,3));
		ship.stillFloating();
	}

	@Test
	void testGetTopMostPos() {
		IShip ship;
		ship = new Caravel(Compass.NORTH,new Position(2,3));
		ship.getTopMostPos();
		ship = new Barge(Compass.NORTH,new Position(2,3));
		ship.getTopMostPos();
	}

	@Test
	void testGetBottomMostPos() {
		IShip ship;
		ship = new Carrack(Compass.NORTH,new Position(2,3));
		ship.getBottomMostPos();
		ship = new Barge(Compass.NORTH,new Position(2,3));
		ship.getBottomMostPos();
	}

	@Test
	void testGetLeftMostPos() {
		IShip ship;
		ship = new Caravel(Compass.WEST,new Position(2,3));
		ship.getLeftMostPos();
		ship = new Barge(Compass.NORTH,new Position(2,3));
		ship.getLeftMostPos();
	}

	@Test
	void testGetRightMostPos() {
		IShip ship;
		ship = new Carrack(Compass.WEST,new Position(2,3));
		ship.getRightMostPos();
		ship = new Barge(Compass.WEST,new Position(2,3));
		ship.getRightMostPos();
	}

	@Test
	void testOccupies() {
		IShip ship;
		ship = new Caravel(Compass.NORTH,new Position(2,3));
		ship.occupies(new Position(2,3));
		ship.occupies(new Position(0,0));
	}

	@Test
	void testTooCloseTo() {
		IShip ship1 = new Caravel(Compass.NORTH,new Position(2,3));
		IShip ship2 = new Caravel(Compass.NORTH,new Position(2,3));
		IShip ship3 = new Caravel(Compass.NORTH,new Position(2,2));
		IShip ship4 = new Caravel(Compass.NORTH,new Position(0,0));
		ship1.tooCloseTo(ship2);
		ship1.tooCloseTo(ship3);
		ship1.tooCloseTo(ship4);
	}

	@Test
	void testGetPositions() {
		IShip ship = new Caravel(Compass.NORTH,new Position(2,3));
		ship.getPositions();
	}

	@Test
	void testShoot() {
		IShip ship = new Caravel(Compass.NORTH,new Position(2,3));
		ship.shoot(new Position(2,3));
		ship.shoot(new Position(0,0));
	}

	@Test
	void testToString() {
		IShip ship = new Caravel(Compass.NORTH,new Position(2,3));
		ship.toString();
	}

}
